import DashboardLayout from "../../layouts/DashboardLayout";

function Doctors() {

  return (

    <DashboardLayout role="Admin">

      <div className="container-fluid">

        <div className="card shadow">

          <div className="card-header bg-success text-white">

            <h3>👨‍⚕️ Manage Doctors</h3>

          </div>

          <div className="card-body">

            {/* Paste your existing:
                doctorForm
                createDoctor()
                updateDoctor()
                deleteDoctor()
                doctor table
            */}

          </div>

        </div>

      </div>

    </DashboardLayout>

  );

}

export default Doctors;